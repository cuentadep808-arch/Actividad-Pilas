/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pilas;


public class Pila {
    private Nodo tope;
    private int nElementos;
    
    public Pila() {
        this.tope = null;
        this.nElementos = 0;
    }
    public boolean empty() {
        return this.nElementos == 0;
    }
    public void push(Object elemento) {
        Nodo nuevoNodo = new Nodo(elemento);
        nuevoNodo.siguiente = this.tope;
        this.tope = nuevoNodo;
        this.nElementos++;
    }
    public Object pop() {
        if (this.empty()){
            throw new IllegalStateException("Error la pila esta vacia no se puede hacer pop");
            }
        Object datoExtraido = this.tope.dato;
        this.tope = this.tope.siguiente;
        this.nElementos--;
        return datoExtraido;
    }
    public Object peek() {
        if (this.empty()){
        throw new IllegalStateException("Error la pila esta vacia no se puede hacer peek");
    }
        return this.tope.dato;
    }
    public int getnElementos(){
        return this.nElementos;
    }
    
}
