/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pilas;


public class Pilas {

    public static void main(String[] args) {
        Pila pila = new Pila();
        
        System.out.println("Esta vacia la Pila?"+ pila.empty());
        pila.push(10);
        pila.push(20);
        pila.push(30);
        
System.out.println("Numero de elementos: " + pila.getnElementos()); 
        System.out.println("Elemento en el tope (peek): " + pila.peek()); 
        System.out.println("La pila esta vacia?: " + pila.empty());

        System.out.println("Elemento extraido (pop): " + pila.pop()); 
        System.out.println("Nuevo tope (peek): " + pila.peek()); 
        System.out.println("Numero de elementos restantes: " + pila.getnElementos());
    }
}
